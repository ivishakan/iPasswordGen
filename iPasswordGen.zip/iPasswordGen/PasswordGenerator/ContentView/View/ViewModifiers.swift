//  PROJECT PURPOSE ONLY
//  ViewModifiers.swift
//  PasswordGenerator
//
//  Created by Vishakan U S on 02/06/2022.
//

import Foundation
import SwiftUI

extension View {
    func centerH() -> some View {
        HStack {
            Spacer()
            self
            Spacer()
        }
    }
    
    func addNavigationView(title: String) -> some View{
        NavigationView {
            self
                .navigationTitle(title)
        }
    
    }
}
